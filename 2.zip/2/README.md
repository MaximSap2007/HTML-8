# Фото не дороблене!(Практика2)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/NWmvWyL](https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/NWmvWyL).

